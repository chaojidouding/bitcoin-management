#include <stdio.h>
#include <string.h>
#include <inttypes.h>

int aes_encrypt(char *filename,char *outfile,uint8_t *key, uint8_t *iv);
int aes_decrypt(char *filename,char *outfile,uint8_t *key, uint8_t *iv); 
