/*
 * Intermediate Wrapper API for Daan Sprenkels' Shamir secret sharing library
 * Copyright (c) 2022  <shiyuyang@bupt.edu.cn>
 */

#ifndef sss_DEMO1_H_
#define sss_DEMO1_H_

#include "sss.h"
#include "randombytes.h"
#include "hazmat.h"
#include "tweetnacl.h"
#include <inttypes.h>

void writeSecrettoFile(sss_Share *secret,char *filename);
void writeSecretstoFiles(int nos,sss_Share *secret,const char *dirname);
void readSecretfromFile(int snfr,sss_Share *recShares,char *fname);



#endif /* sss_DEMO1_H_ */
