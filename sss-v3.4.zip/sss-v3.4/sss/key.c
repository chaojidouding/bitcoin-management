#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <inttypes.h>
#include <unistd.h>

//openssl rand -hex 16

void keyGen(uint8_t *key){
	uint8_t ch;
	int i=0;

	int ret = system("openssl rand -hex 16 > /tmp/key.txt");
	if(ret == 0)
	{
	}
	

	FILE *fp;
	if((fp=fopen("/tmp/key.txt","rb"))==NULL){
		printf("can't open file!\n");
		exit(0);
	}
	fread(key,32,1,fp);
	fclose(fp);
	if(unlink("/tmp/key.txt") <0)
	{
		printf("unlink call failed");
	}
	
	
	
	
}


/*
int main()
{
	char key[33],ch;
	int i=0;

	system("openssl rand -hex 16 > ./key.txt");
	printf("====================end of openssl\n");
	FILE *fp;
	if((fp=fopen("./key.txt","rb"))==NULL){
		printf("can't open file!\n");
		exit(0);
	}
	ch=getc(fp);
	while(ch!=EOF){
		key[i]=ch;
		ch=getc(fp);
		i++;	

	}
	key[33]='\0';
	printf("%s",key);
	

	
}
*/
