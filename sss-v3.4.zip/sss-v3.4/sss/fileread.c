#include <stdio.h>
#include <unistd.h>
//gcc fileread.c -o fileread
int readfile_encrypt(int *nos,int *snfr,char *filename, char *outname,char *fname){
	
	char tmpfile[100]="/home/bb/Desktop/sss-v3.4/sss/fileread/tempencrypt.txt";
	FILE *fp;
	if((fp=fopen(tmpfile,"r"))==NULL){
		printf("can't open file!\n");
		exit(0);
	}
	fscanf(fp,"%d",nos);
	fscanf(fp,"%d",snfr);
	fscanf(fp,"%s",filename);
	fscanf(fp,"%s",outname);
	fscanf(fp,"%s",fname);
	fclose(fp);
	if(unlink("/tmp/key.txt") <0)
	{
		printf("unlink call failed");
	}

}

int readfile_decrypt(int *snfr,char *secretfile, char *filename1,char *outfile1){
	
	char tmpfile[100]="/home/bb/Desktop/sss-v3.4/sss/fileread/tempdecrypt.txt";
	FILE *fp;
	if((fp=fopen(tmpfile,"r"))==NULL){
		printf("can't open file!\n");
		exit(0);
	}
	fscanf(fp,"%d",snfr);
	fscanf(fp,"%s",secretfile);
	fscanf(fp,"%s",filename1);
	fscanf(fp,"%s",outfile1);
	
	fclose(fp);
	if(unlink("/tmp/key.txt") <0)
	{
		printf("unlink call failed");
	}

}

int readfile_choice(char *a){
	char tmpfile[100]="/home/bb/Desktop/sss-v3.4/sss/fileread/choice.txt";
	FILE *fp;
	if((fp=fopen(tmpfile,"r"))==NULL){
		printf("can't open file!\n");
		exit(0);
	}
	fscanf(fp,"%c",a);
	
	fclose(fp);
	if(unlink("/tmp/key.txt") <0)
	{
		printf("unlink call failed");
	}


}

/*
int main(){
	
	int nos,snfr;
	char filename[100],outfile[100],fname[100],secretfile[100],filename1[100],outfile1[100];
	readfile_encrypt(&nos,&snfr,filename,outfile,fname);
	printf("nos=%d\n",nos);
	printf("snfr=%d\n",snfr);
	printf("filename=%s\n",filename);
	printf("outfile=%s\n",outfile);
	printf("fname=%s\n",fname);
	printf("============\n");
	readfile_decrypt(&snfr,secretfile, filename1,outfile1);
	printf("snfr=%d\n",snfr);
	printf("secretfile=%s\n",secretfile);
	printf("filename1=%s\n",filename1);
	printf("outfile1=%s\n",outfile1);

}
*/
