#include "sss.h"
#include "randombytes.h"
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

void printarry(sss_Share *secret){

printf("%x\n",secret);


/*
printf("%x\n",secret[0]);
printf("%x\n",&secret[0]);
printf("%x\n",*secret[0]);
sss_Share g;
g[0]=*shares[0];
printf("%x\n",g[0]);
*/
}

void testCharArray1()
{
char text[10];
text[0]='a';
text[1]='b';
text[2]='0';
printf("text = %s\n",text);  //
printf("text = %x\n",text);
//printf("text = %7s\n",text); 
int i;
for(i=0;i<10;i++)
	printf("text[%d] = %x\n",i,text[i]); 
}

void testCharArray2()
{
char text[10]={};
text[0]='a';
text[1]='b';
printf("text = %s\n",text);  //
printf("text = %x\n",text);
int i;
for(i=0;i<10;i++)
	printf("text[%d] = %x\n",i,text[i]); 
}

void testShare()
{

}

typedef char Line[10];

void testLine()
{
	Line t;
	Line lines[3];

char text[10]={};
text[0]='a';
text[1]='b';
printf("text = %s\n",text);  //
printf("text = %x\n",text);
int i;
for(i=0;i<10;i++)
	printf("text[%d] = %x\n",i,text[i]); 

	strcpy(t,text);
printf("t=%s\n",t);
printf("t=%x\n",t);
for(i=0;i<10;i++)
	printf("t[%d] = %x\n",i,t[i]); 

strcpy(lines[0],text);
text[2]='c'; strcpy(lines[1],text);
text[3]='d'; strcpy(lines[2],text);


int j;
for(i=0;i<3;i++)
{
	printf("lines[%d] = ",i);
	for(j=0;j<10;j++)
	{
		printf("%x,",lines[i][j]);
	}
	printf("\n");
}

printf("============ \n");
testLinesPointer(&lines[0]);

}

void testLinesPointer(Line * p)
{
	int i;
	for(i=0;i<3;i++)
	printf("p[%d] = %x\n",i,p[i]); 

int j;
for(i=0;i<3;i++)
{
	printf("p[%d] = ",i);
	for(j=0;j<10;j++)
	{
		printf("%x,",p[i][j]);
	}
	printf("\n");
}


}

int main(){

//testCharArray1();//uninitialised array
//testCharArray2();//initialised array
testLine();

/*
sss_Share data;
sss_Share shares[10];
strcpy(data,"123");
sss_create_shares(shares, data, 5, 4);

printf("data = %s\n",data);
printf("data = %x\n",data);
printf("&data = %x\n",&data);
printf("data[0] = %x\n",data[0]);  // 0x31, '1'
printf("&data[0] = %x\n",&data[0]);
printf("data[1] = %x\n",data[1]);
printf("&data[1] = %x\n",&data[1]);


sss_create_shares(shares, data, 5, 4);
printf("shares = %x\n",shares);
printf("shares[0] = %x\n",shares[0]);
printf("&shares[0] = %x\n",&shares[0]);
printf("shares[0][0] = %x\n",shares[0][0]);
printf("&shares[0][0] = %x\n",&shares[0][0]);
printf("shares[0][1] = %x\n",shares[0][1]);
printf("shares[1] = %x\n",shares[1]);
printf("&shares[1] = %x\n",&shares[1]);
//printf("%x\n",*shares[0]);

printf("=======================================\n");

printarry(&shares[0]);*/
}
