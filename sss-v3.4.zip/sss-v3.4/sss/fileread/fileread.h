#include <stdio.h>
#include <unistd.h>
//gcc fileread.c -o fileread
int readfile_encrypt(int *nos,int *snfr,char *filename, char *outname,char *fname);
int readfile_decrypt(int *snfr,char *secretfile, char *filename1,char *outfile1);
