#include <stdio.h>
#include <unistd.h>
//gcc fileread.c -o fileread
int readfile_encrypt(int *nos,int *snfr,char *filename, char *outname,char *fname){
	
	char tmpfile[100]="/home/bb/Desktop/sss-v2.26testv1/sss/fileread/test";
	FILE *fp;
	if((fp=fopen(tmpfile,"rb"))==NULL){
		printf("can't open file!\n");
		exit(0);
	}
	fread(nos,sizeof(int),1,fp);
	fread(snfr,sizeof(int),1,fp);
	fread(filename,100,1,fp);
	fread(outfile,100,1,fp);
	fread(fname,100,1,fp);
	fclose(fp);
	if(unlink("/tmp/key.txt") <0)
	{
		printf("unlink call failed");
	}

}

int readfile_decrypt(int *snfr,char *secretfile, char *filename1,char *outfile1){
	
	char tmpfile[100]="/home/bb/Desktop/sss-v2.26testv1/sss/fileread/test";
	FILE *fp;
	if((fp=fopen(tmpfile,"rb"))==NULL){
		printf("can't open file!\n");
		exit(0);
	}
	
	fread(snfr,sizeof(int),1,fp);
	fread(secretfile,100,1,fp);
	fread(filename1,100,1,fp);
	fread(outfile1,100,1,fp);
	fclose(fp);
	if(unlink("/tmp/key.txt") <0)
	{
		printf("unlink call failed");
	}

}


int main(){
	
	char fname[100]={};
	readfile(fname);
	printf("%s",fname);

	

}
