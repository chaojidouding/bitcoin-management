#include <stdio.h>
#include <string.h>
#include <inttypes.h>

//openssl enc -aes -128 -cbc -in filename -out outfile -K -iv -e
//openssl enc -aes -128 -cbc -in filename -out outfile -K -iv -d



int aes_encrypt(char *filename,char *outfile,uint8_t *key, uint8_t *iv)
{
	//char key[100] = "E05A84ED2068B3DEE402304AD12F4A40" ;
	//char iv[100] = "E27DCFC8DF33FA58E335BEBB5978B7B4";
	//filename[100] = "/home/bb/Desktop/aes-encryption/plain_text";
	//outfile[100] = "/home/bb/Desktop/aes-encryption/encrypted_text";
	int i;
	char k[33],v[33];
	for(i=0;i<32;i++)
	{
		k[i]=key[i];
		v[i]=iv[i];
	}
	k[32]='\0';
	v[32]='\0';
	char command[700] = {};
	strcpy(command,"openssl enc -aes-128-cbc -in ");
	strcat(command,filename);
	strcat(command," -out ");
	strcat(command,outfile);
	strcat(command," -K ");
	strcat(command,k);
	strcat(command,"  -iv ");
	strcat(command,v);
	strcat(command,"  -e");
	printf("%s\n",command);
	system(command);





}

int aes_decrypt(char *filename,char *outfile,uint8_t *key, uint8_t *iv)
{
	//char key[100] = "E05A84ED2068B3DEE402304AD12F4A40" ;
	//char iv[100] = "E27DCFC8DF33FA58E335BEBB5978B7B4";
	//	char filename[100] = "/home/bb/Desktop/aes-encryption/encrypted_text";
	//outfile[100] = "/home/bb/Desktop/aes-encryption/decrypted_text";
	int i;
	char k[33],v[33];
	for(i=0;i<32;i++)
	{
		k[i]=key[i];
		v[i]=iv[i];
	}
	k[32]='\0';
	v[32]='\0';
	printf("k=%s",k);
	printf("v=%s",v);
	char commend[700] = {};
	strcpy(commend,"openssl enc -aes-128-cbc -in ");
	strcat(commend,filename);
	strcat(commend," -out ");
	strcat(commend,outfile);
	strcat(commend," -K ");
	strcat(commend,k);
	strcat(commend,"  -iv ");
	strcat(commend,v);
	strcat(commend,"  -d");
	system(commend);





}

