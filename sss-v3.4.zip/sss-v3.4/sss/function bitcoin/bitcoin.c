int bitcoin_encrypt(){

char filename[100],outfile[100],fname[100],wname[100];
				//jiami 函数接口
				//char filename[100],outfile[100],fname[100];
				printf("请输入要加密到的文件数目\n");
				//nos=3;
				scanf("%d",&nos);
				printf("请输入还原密钥所需的文件数目\n");
				//snfr=2;
				scanf("%d",&snfr);
				printf("请输入需要加密的文件路径\n");
				char filename[100]="/home/bb/bitcoin/wallets/";
				scanf("%s",wname);
				strcat(filename,wanme);
				strcat(filename,"/");
				strcat(filename,wname);
			
				
				printf("请输入加密输出的文件路径\n");
				//char outfile[100]="/home/bb/Desktop/sss-v2.26/sss/data/encrypted";
				scanf("%s",outfile);
				printf("请输入密钥分片输出路径\n");
				//char fname[100]="/home/bb/Desktop/sss-v2.26/sss/data/";
				scanf("%s",fname);
				printf("=============keyGen start\n");
				keyGen(aes_key);
				keyGen(aes_iv);
				for(k=0;k<32;k++)
				{
					key[k] = aes_key[k];
					key[k+32] = aes_iv[k];
				}
				printf("=============keyGen end\n");
				//  key[] <-- aes_key[],aes_iv[]	
				
				
				printf("=============encrypt start\n");				
				aes_encrypt(filename,outfile,aes_key,aes_iv);

				printf("=============encrypt end\n");
				//aes_decrypt(outfile,"/home/bb/Desktop/sss-v2.26/sss/data/decrypted",aes_key,aes_iv);
				
				strncpy(data, key, sizeof(data));
				printf("=============dataGen end\n");
				sss_create_shares(shares, data, nos, snfr);
				printf("=============sss end\n");
				writeSecretstoFiles(nos,shares,fname);
				printf("=============write secrets end\n");
				break;
}
