// gcc demo1.c -o demo1 randombytes.o sss.o hazmat.o tweetnacl.o
#include "sss.h"
#include "randombytes.h"
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>


void writeSecrettoFile(sss_Share *secret,char *filename);
void writeSecretstoFiles(int nos,sss_Share *secret,const char *dirname);
void readSecretfromFile(int snfr,sss_Share *recShares,char *fname);



/*
uint8_t key[sss_MLEN];

int get_key(uint8_t *key1){
	strncpy(key1,"i am a key",sizeof(key1));
	return 0;
}
*/

//"/home/bb/Desktop/Untitled Folder/tesh.txt"
void writeSecretstoFiles(int nos,sss_Share *secret,const char *dirname)
{
	int no=0;
	for(no=0;no<nos;no++)
	{
		char str_no[10]={};
		char filename[100] = {};
		strcat(filename,dirname);
		strcat(filename,"no");
		printf("no=%d\n",no);
		sprintf(str_no, "%d", no);
		strcat(filename,str_no);
		strcat(filename,".txt");
		printf("%s\n",filename);
		writeSecrettoFile(&secret[no],filename);	
	}
}



void writeSecrettoFile(sss_Share *secret,char *filename)
{

	FILE *fp;
	//float f=123.24,g;
	sss_Share g;
	int i;
	//sss_Share s=*secret;
	printf("secret=");
	for(i=0;i<sizeof(sss_Share);i++){
		printf("%x",secret[0][i]);
	}
	printf("\n=============\n");
	//
	if((fp=fopen(filename,"wb"))==NULL){
		printf("Cannot open the file!\n");
		exit(0);	
	}
	//fwrite(&f,sizeof(float),1,fp);
	fwrite(secret,sizeof(sss_Share),1,fp);
	fclose(fp);

	if((fp=fopen(filename,"rb"))==NULL){
		printf("Cannot open the file!\n");
		exit(0);
	}
	fread(g,sizeof(sss_Share),1,fp);
	//printf("******g=%.2f\n",g);
	
		
		printf("g=");
		for(i=0;i<113;i++){
			printf("%x",g[i]);
		}
		printf("\n===============\n");
	fclose(fp);
	

}


void readSecretfromFile(int snfr,sss_Share *recShares,char *fname)
{
	
	printf("snfr=%d,fname=%s\n",snfr,fname);

	int no=0;
	for(no=0;no<snfr;no++)
	{	
		char filename[100] = {};
		char str_no[10]={};
		strcpy(filename,fname);
		strcat(filename,"no");
		printf("no=%d\n",no);

		sprintf(str_no, "%d",no);
		printf("str_no=%s\n",str_no);

		printf("filename=%s\n",filename);

		strcat(filename,str_no);

		strcat(filename,".txt");
		printf("filename=%s\n",filename);
		printf("\n===============end of filename creation\n");

		FILE *fp;
		if ((fp = fopen(filename, "rb")) == NULL)
		{
			printf("fail to read");
			return 3;//3-error of read file
		}
		printf("\n===============file open\n");
		
  		fread ( recShares[no], sizeof(sss_Share), 1, fp );
		printf("\n===============end of read file\n");
		int i;
		
		printf("recShares[%d]=",no);
		for(i=0;i<113;i++){
		
			printf("%x",recShares[no][i]);
		}
		printf("\n===============end of a round\n");
	
		
		fclose(fp);
		
	
	}
	printf("\n===============end of readSecretfromFile\n");
}
/*
int main(int argc, char** argv)
{
	//set the arguments of shares
	int nos;//number of shares
        int snfr;//shares needed for recover
	int res_get_key=0;
	
	//user interface	
	printf("number of shares:");
        scanf("%d",&nos);
        printf("shares needed for recover:");
        scanf("%d",&snfr);
	//exception handing
	if ( nos<=0) return 2;//2-error of input error nos
	//check the the set arguments
        printf("nos=%d\n",nos);
	printf("snfr=%d\n",snfr);
	
	



	uint8_t data[sss_MLEN], restored[sss_MLEN];
	sss_Share shares[100];
	sss_Share recShares[100];

	size_t idx;
	int tmp;



	// Read a message to be shared

        res_get_key=get_key(key);//0:success;1:fail1;2:fail2;...

	if (res_get_key != 0) 
	{// fail
		printf("get_key error:%d",res_get_key);
		return 1;//1-error of get_key;
	}
        
        printf("get_key() res_get_key:%d\n",res_get_key);
	printf("get_key() key is:%s\n",key);
	
        // success to get key

	//strncpy(data, "Tyler Durden isn't real.", sizeof(data));
	//pass the key to string data in the sss-function
        strncpy(data, key, sizeof(data));
	//check the data
        printf("data=%s\n",data);

	

	// Split the secret into 5(nos) shares (with a recombination theshold of 4(snfr))
	sss_create_shares(shares, data, nos, snfr);
	
	
	

	

	//check the shares
	int k;
	int i;
	for(k=0;k<nos;k++){
		printf("k=%d\n",k);
		printf("share[%d]=",k);
		for(i=0;i<113;i++){
			printf("%x",shares[k][i]);
		}
	}
	printf("\n==========\n");



	//write shares into files
	char filename[100] = {};
	
	//write shares into files
 	writeSecretstoFiles(nos,&shares);
	


	
		
	
	printf("**************end of wirte share[] to files\n");
	

	// Combine some of the shares to restore the original secret
        //sss_Share recShares[2];
        // read  shares[0]  from local file1 and assign to recShares[0]
        //recShares[0]=; 
        // ead  shares[1]  from U Disk and assign to recShares[1]
	//recShares[1]=;
	printf("************begin of read files to recShares[]\n");

	
	//recover the key	
             
		
		
	
	

	tmp = sss_combine_shares(restored, recShares, snfr); 

	printf("************en d of  sss_combine_shares()\n");

	printf("restored=%s \n",restored);
	assert(tmp == 0);
	assert(memcmp(restored, data, sss_MLEN) == 0);

	return 0;//0-success
}
*/
