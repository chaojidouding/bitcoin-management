// gcc demo2.c -o demo2 randombytes.o sss.o hazmat.o tweetnacl.o
#include "sss.h"
#include "randombytes.h"
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

// syy.h
void writeSecrettoFile(sss_Share *secret,char *filename);
void writeSecretstoFiles(int nos,sss_Share *secret);

int readSecretfromtFile(sss_Share *secret, char *filename);
void readSecretsfromtFiles(int snfr,sss_Share *recShares);

// syy.c
void writeSecretstoFiles(int nos,sss_Share *secret)
{
	char filename[100] = {};
	int i=0;
	for(i=0;i<nos;i++){
		char str_no[10]={};
		strcpy(filename,"/home/bb/Desktop/sss/data/no");
		printf("no=%d\n",i);
		sprintf(str_no, "%d", i);
		strcat(filename,str_no);
		strcat(filename,".txt");
		printf("%s\n",filename);
		writeSecrettoFile(&secret[i],filename);	
	}
}

void writeSecrettoFile(sss_Share *secret, char *filename)
{
	FILE *fp;

	if((fp=fopen(filename,"wb"))==NULL){
		printf("Cannot open the file!\n");
		exit(0);	
	}	
	fwrite(secret,sizeof(sss_Share),1,fp);
	fclose(fp);
}

void readSecretsfromtFiles(int snfr,sss_Share *recShares)
{
	
}

int readSecretfromtFile(sss_Share *secret, char *filename)
{
	FILE *fp;
	if ((fp = fopen(filename, "rb")) == NULL)
	{
			printf("fail to read");
			return 3;//3-error of read file
	}
	fread (secret, sizeof(sss_Share), 1, fp );
	printf("recShares[]=%x\n",secret);
	fclose(fp);
}



////////////////////////////////////////////// 
// Testing program
// (t,n) shamir secret sharing
void initParameters(int *t,int *n, uint8_t *key)
{
	//user interface	
	printf("number of shares:");
  scanf("%d",n);
  printf("shares needed for recover:");
  scanf("%d",t);
	//exception handling
	if ( *n<=0) exit(0);
	
	//check the the set arguments
	//printf("nos=%d\n",*n);
	//printf("snfr=%d\n",*t);
	printf("(t,n)=(%d,%d)\n",*t,*n);

//  uint8_t key[sss_MLEN];
//	// Read a message to be shared
//  res_get_key=get_key(key);//0:success;1:fail1;2:fail2;...
//	if (res_get_key != 0) 
//	{// fail
//		printf("get_key error:%d",res_get_key);
//		return 1;//1-error of get_key;
//	}
//	printf("get_key() res_get_key:%d\n",res_get_key);
//	printf("get_key() key is:%s\n",key);
//	// success to get key
}

int get_key(uint8_t *key1){
	strncpy(key1,"i am a key",sizeof(key1));
	return 0;
}

// init parameters from command line: demo2 -t 2 -n 3 -key 'this is my key'
void initParametersCmd()
{
	
}

// sss_SHARE_LEN
// typedef uint8_t sss_Share[sss_SHARE_LEN];
void printShare(sss_Share *share)
{
	uint8_t *p;
	p=&share;
	int i;
	for(i=0;i<sss_SHARE_LEN;i++)
	{
		printf("%x",*(p+i));
	}
	printf("\n");
}


void test()
{
	printf("Length of the message: sss_MLEN = %d\n",sss_MLEN);
	printf("Length of a SSS share: sss_SHARE_LEN = %d\n",sss_SHARE_LEN);
}


void testSSS(int snfr,int nos, char *message)
{
	uint8_t data[sss_MLEN], restored[sss_MLEN];
	sss_Share shares[100];
	sss_Share recShares[100];
	
	//pass the key to string data in the sss-function
	strncpy(data, message, sizeof(data));
	//strncpy(data, "Tyler Durden isn't real.", sizeof(data));
	//check the data
	printf("data=%s\n",data);

	// Split the secret into 5(nos) shares (with a recombination threshold of 4(snfr))
	sss_create_shares(shares, data, nos, snfr);

	//check the shares
	int k;
	for(k=0;k<nos;k++){
		printf("k=%d	",k);
		printf("shares[%d]=%x\n",k,shares[k]);
		//printf("shares[%d]=%x\n",k,&shares[k]);
		//printShare(&shares[k]);
	}

	printf("======= \n");
	//write shares into files
	char filename[100] = {};
	
	//write shares into files
 	//writeSecretstoFiles(nos,&shares);
	
	//filename="/home/bb/Desktop/sss/data/no10.txt";
	strcpy(filename,"/home/bb/Desktop/sss/data/s0.txt");
	writeSecrettoFile(&shares[0],filename);
	readSecretfromtFile(&recShares[0],filename);
/*
	FILE *fp;
	//float f=123.24,g;
	//sss_Share g;	
	//
	if((fp=fopen(filename,"wb"))==NULL){
		printf("Cannot open the file!\n");
		exit(0);	
	}
	//fwrite(&f,sizeof(float),1,fp);
	//printf("******f=%.2f\n",f);
	printf("shares[0]=%x\n",shares[0]);	
	fwrite(&shares[0],sizeof(sss_Share),1,fp);
	fclose(fp);

	if((fp=fopen(filename,"rb"))==NULL){
		printf("Cannot open the file!\n");
		exit(0);
	}
	fread(&recShares[0],sizeof(sss_Share),1,fp);
	//fread(&g,sizeof(float),1,fp);	//printf("******g=%.2f\n",g);
	//fread(&g,sizeof(sss_Share),1,fp);printf("*****g=%x\n",g);
	fclose(fp);		
*/
	assert(memcmp(shares[0], recShares[0], sss_SHARE_LEN) == 0);
	//assert(memcmp(shares[0], g, sss_SHARE_LEN) == 0);
	//printShare(&shares[0]);printShare(&g);
	//printShare(shares[0]);printShare(g);
	//printf("shares[0]=%s\n",shares[0]);
	//printf("*****g=%s\n",g);
	printf("**************end of wirte share[] to files\n\n\n");
	//assert(memcmp(shares[1], g, sss_SHARE_LEN) == 0);

	char filename1[100] = {};	
	strcpy(filename1,"/home/bb/Desktop/sss/data/s1.txt");
	writeSecrettoFile(&shares[1],filename1);
	readSecretfromtFile(&recShares[1],filename1);
	assert(memcmp(shares[1], recShares[1], sss_SHARE_LEN) == 0);

	char filename2[100] = {};	
	strcpy(filename2,"/home/bb/Desktop/sss/data/s2.txt");
	writeSecrettoFile(&shares[2],filename2);
	readSecretfromtFile(&recShares[2],filename2);
	assert(memcmp(shares[2], recShares[2], sss_SHARE_LEN) == 0);

//assert(1==0);
	// Combine some of the shares to restore the original secret
        //sss_Share recShares[2];
        // read  shares[0]  from local file1 and assign to recShares[0]
        //recShares[0]=; 
        // ead  shares[1]  from U Disk and assign to recShares[1]
	//recShares[1]=;
	printf("************begin of read files to recShares[]\n");

	
	//recover the key	
	//readSecretFile(snfr,&recShares);	

	
	int tmp;
	tmp = sss_combine_shares(restored, recShares, snfr); 
	//tmp = sss_combine_shares(restored, shares, snfr); 

	printf("************end of  sss_combine_shares()\n");

	printf("restored=%s \n",restored);
	printf("data=%s \n",data);
	assert(tmp == 0);
	assert(memcmp(restored, data, sss_MLEN) == 0);
}

int main(int argc, char** argv)
{
	test();

	//set the arguments of shares
	int nos;//number of shares
	int snfr;//shares needed for recover
	int res_get_key=0;
	uint8_t key[sss_MLEN];
	
	initParameters(&snfr, &nos, key);

printf("======= \n");
// testSSS(snfr,nos,key)
testSSS(2,3,"this is my secret key");

	return 0;//0-success
}
