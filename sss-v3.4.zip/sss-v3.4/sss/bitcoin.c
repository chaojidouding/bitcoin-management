//gcc bitcoin.c -o bitcoin randombytes.o sss.o hazmat.o tweetnacl.o demo1.o

#include <stdio.h>
#include "demo1.h" 
#include "randombytes.h"
#include "tweetnacl.h"
#include "sss.h"
#include "tweetnacl.h"
#include "aes_sys.h" 
#include "key.h"
char a[10],b[10];
uint8_t key[sss_MLEN];
FILE *fp;
int main()
{
	sss_Share shares[100];
	sss_Share recShares[100];
	uint8_t data[sss_MLEN], restored[sss_MLEN];
	int nos,snfr,i;
	int k;
	uint8_t aes_key[32],aes_iv[32];
	while(1)
	{
		printf("������Ҫִ�еĹ��� 1:�ָ���Կ2:ֱ������bitcoin core3������ 4���˳�:\n"); 
		//scanf("%s",a+1);
		readfile_choice(&a[1]);
		
		if(a[1]=='1')
		{
			//huifumiyao �����ӿ�
			//char fname[100],outfile[100];
			//fname1 ��Żָ�������Կ
			//outfile1 ��aes���Ľ��ܳ�������
			//filename1 ��Կ��Ƭ��·��
			//secretfile ����
			char secretfile[100],filename1[100],outfile1[100];
			
			readfile_decrypt(&snfr,secretfile, filename1,outfile1);
			readSecretfromFile(snfr,recShares,filename1);
			printf("\n===============end of readSecretfromFile\n");
			printf("\n===============begain of sss_combine_shares\n");
			sss_combine_shares(restored, recShares, snfr); 
			printf("\n===============end of sss_combine_shares\n");
			char restored_ch[65];			
			for(k=0;k<64;k++)
			{
				restored_ch[k]=restored[k];
			}
			restored_ch[64]='\0';
			printf("restored_ch=%s",restored_ch);
			printf("\n");
			/*
			char fname1[100]="/home/bb/Desktop/sss-v2.26/sss/data/recovered";
			FILE *fp;
			fp=fopen(fname1,"wb");
			//fprintf(fp,"%s",restored);
			fwrite(restored,64,1,fp);
			fclose(fp);
			*/
			for(k=0;k<32;k++)
				{
					aes_key[k] = restored[k];
					aes_iv[k] = restored[k+32];
				}
			
			char k[33],v[33];
			for(i=0;i<32;i++)
			{
				k[i]=aes_key[i];
				v[i]=aes_iv[i];
			}
			k[32]='\0';
			v[32]='\0';
			printf("k=%s\n",k);
			printf("v=%s\n",v);
			printf("secretfile=%s\n",secretfile);
			printf("outfile1=%s\n",outfile1);

			printf("\n===============start of aes_decrypt\n");
			aes_decrypt(secretfile,outfile1,aes_key,aes_iv);
			break;
		}
		else if(a[1]=='2')
		{
//			system("bitcoincore.exe");
		}
		else if(a[1]=='3')
		{
				char filename[100],outfile[100],fname[100];
				readfile_encrypt(&nos,&snfr,filename, outfile,fname);
				printf("=============keyGen start\n");
				keyGen(aes_key);
				keyGen(aes_iv);
				for(k=0;k<32;k++)
				{
					key[k] = aes_key[k];
					key[k+32] = aes_iv[k];
				}
				printf("=============keyGen end\n");
				//  key[] <-- aes_key[],aes_iv[]	
				
				
				printf("=============encrypt start\n");				
				aes_encrypt(filename,outfile,aes_key,aes_iv);

				printf("=============encrypt end\n");
				//aes_decrypt(outfile,"/home/bb/Desktop/sss-v2.26/sss/data/decrypted",aes_key,aes_iv);
				
				strncpy(data, key, sizeof(data));
				printf("=============dataGen end\n");
				sss_create_shares(shares, data, nos, snfr);
				printf("=============sss end\n");
				writeSecretstoFiles(nos,shares,fname);
				printf("=============write secrets end\n");
				break;
		}
		else if(a[1]=='4')
			break;
	}
	return 0;
}

