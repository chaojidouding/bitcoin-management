#include "sss.h"
#include "randombytes.h"
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

#define MAX_NOS 5

uint8_t key[sss_MLEN];

int get_key(uint8_t *key1){
	strncpy(key1,"i am a key",sizeof(key1));
	return 0;
}

int main()
{
	int nos;//number of shares
        int snfr;//shares needed for recover
	int res_get_key=0;
		
	printf("number of shares:");
        scanf("%d",&nos);
        printf("shares needed for recover:");
        scanf("%d",&snfr);
        printf("nos=%d\n",nos);
	printf("snfr=%d\n",snfr);

	uint8_t data[sss_MLEN], restored[sss_MLEN];
	sss_Share shares[MAX_NOS];
	sss_Share recShares[MAX_NOS];

	size_t idx;
	int tmp;

	// Read a message to be shared

        res_get_key=get_key(key);//0:success;1:fail1;2:fail2;...

	if (res_get_key != 0) {// fail
		printf("get_key error:%d",res_get_key);
		return 1;//1-error of get_key;
	}
        
        printf("get_key() res_get_key:%d\n",res_get_key);
	printf("get_key() key is:%s\n",key);
	
        // success to get key

	//strncpy(data, "Tyler Durden isn't real.", sizeof(data));
        strncpy(data, key, sizeof(data));

        printf("data=%x\n",data);

	

	// Split the secret into 5(nos) shares (with a recombination theshold of 4(snfr))
	printf("*****begin of sss_create_shares()*****\n");

	sss_create_shares(shares, data, nos, snfr);
	
	printf("*****end of sss_create_shares()*****\n");
	printf("nos=%d snfr=%d\n",nos,snfr);

	if ( nos<=0) return 2;//2-error of input error nos

/*	
	int k;
	for(k=0;k<nos;k++){
		printf("k=%d\n",k);
		printf("shares[k]=%d\n",shares[k]);
	}

*/
	// write shares[0] into local file1; write shares[1] into U Disk; write shares[2] into mobile phone
	int no=0;
	for(no=0;no<nos;no++){
		printf("no=%d\n",no);
		
		printf("shares[no]=%x\n",shares[no]);
	
   		FILE *fp ;
		char filename[100] = {};
		char str_no[10]={};

		strcpy(filename,"/home/bb/Desktop/sss/data/no");

		sprintf(str_no, "%d", no);

		strcat(filename,str_no);

		strcat(filename,".txt");

		printf("filename=%s\n",filename);
 
   		fp = fopen(filename, "w+");
   		fprintf(fp, "%x",shares[no]);
   	
   		fclose(fp);

	}
	printf("**************end of wirte share[] to files\n");
	
	
	// Combine some of the shares to restore the original secret
        //sss_Share recShares[2];
        // read  shares[0]  from local file1 and assign to recShares[0]
        //recShares[0]=; 
        // ead  shares[1]  from U Disk and assign to recShares[1]
	//recShares[1]=;
	printf("************begin of read files to recShares[]\n");
	for(no=0;no<nos;no++){
		
	
   		FILE *fp ;
		char filename[100] = {};
		char str_no[10]={};

		strcpy(filename,"/home/bb/Desktop/sss/data/no");

		printf("no=%d\n",no);

		sprintf(str_no, "%d", no);

		strcat(filename,str_no);

		strcat(filename,".txt");
		printf("filename=%s\n",filename);
             
		if ((fp = fopen(filename, "r")) == NULL)
		{
			printf("fail to read");
			return 3;//3-error of read file
		}
  		fscanf(fp, "%x",&recShares[no]);

		fclose(fp);
		printf("recShares[no]=%x\n",recShares[no]);
	}
	printf("************end of read files to recShares[]\n");

	printf("************begin of  sss_combine_shares()\n");

	tmp = sss_combine_shares(restored, recShares, snfr); 

	printf("************end of  sss_combine_shares()\n");

	printf("restored=%x \n",restored);
	assert(tmp == 0);
	assert(memcmp(restored, data, sss_MLEN) == 0);

	return 0;//0-success

}
